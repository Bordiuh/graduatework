<?php

/* Theme setup section
-------------------------------------------------------------------- */
if (!function_exists('junotoys_sc_tabs_theme_setup')) {
	add_action( 'junotoys_action_before_init_theme', 'junotoys_sc_tabs_theme_setup' );
	function junotoys_sc_tabs_theme_setup() {
		add_action('junotoys_action_shortcodes_list', 		'junotoys_sc_tabs_reg_shortcodes');
		if (function_exists('junotoys_exists_visual_composer') && junotoys_exists_visual_composer())
			add_action('junotoys_action_shortcodes_list_vc','junotoys_sc_tabs_reg_shortcodes_vc');
	}
}



/* Shortcode implementation
-------------------------------------------------------------------- */


if (!function_exists('junotoys_sc_tabs')) {	
	function junotoys_sc_tabs($atts, $content = null) {
		if (junotoys_in_shortcode_blogger()) return '';
		extract(junotoys_html_decode(shortcode_atts(array(
			// Individual params
			"initial" => "1",
			"style" => "1",
			// Common params
			"id" => "",
			"class" => "",
			"animation" => "",
			"css" => "",
			"width" => "",
			"height" => "310px",
			"top" => "",
			"bottom" => "",
			"left" => "",
			"right" => ""
		), $atts)));
	
		$css .= ($css ? ';' : '') . junotoys_get_css_position_from_values($top, $right, $bottom, $left);
		$css .= junotoys_get_css_dimensions_from_values($width, $height);
	
		if (empty($id)) $id = 'sc_tabs_'.str_replace('.', '', mt_rand());
	
		junotoys_storage_set('sc_tab_data', array(
			'counter'=> 0,
            'height' => junotoys_prepare_css_value($height),
            'id'     => $id,
            'titles' => array()
            )
        );
	
		$content = do_shortcode($content);
	
		$sc_tab_titles = junotoys_storage_get_array('sc_tab_data', 'titles');
	
		$initial = max(1, min(count($sc_tab_titles), (int) $initial));
	
		$tabs_output = '<div' . ($id ? ' id="'.esc_attr($id).'"' : '') 
							. ' class="sc_tabs sc_tabs_style_'.esc_attr($style) . (!empty($class) ? ' '.esc_attr($class) : '') . '"'
							. ($css!='' ? ' style="'.esc_attr($css).'"' : '') 
							. (!junotoys_param_is_off($animation) ? ' data-animation="'.esc_attr(junotoys_get_animation_classes($animation)).'"' : '')
							. ' data-active="' . ($initial-1) . '"'
							. '>'
						.'<ul class="sc_tabs_titles">';
		$titles_output = '';
		for ($i = 0; $i < count($sc_tab_titles); $i++) {
			$classes = array('sc_tabs_title');
			if ($i == 0) $classes[] = 'first';
			else if ($i == count($sc_tab_titles) - 1) $classes[] = 'last';
			$titles_output .= '<li class="'.join(' ', $classes).'" style="height: calc(100% / '.count($sc_tab_titles).');">'
								. '<a href="#'.esc_attr($sc_tab_titles[$i]['id']).'" class="theme_button" id="'.esc_attr($sc_tab_titles[$i]['id']).'_tab"><span class="icon icon-right"></span></a>'
								. '</li>';
		}
	
		wp_enqueue_script('jquery-ui-tabs', false, array('jquery','jquery-ui-core'), null, true);
		wp_enqueue_script('jquery-effects-fade', false, array('jquery','jquery-effects-core'), null, true);
	
		$tabs_output .= $titles_output
			. '</ul>' 
			. ($content)
			.'</div>';
		return apply_filters('junotoys_shortcode_output', $tabs_output, 'trx_tabs', $atts, $content);
	}
	junotoys_require_shortcode("trx_tabs", "junotoys_sc_tabs");
}


if (!function_exists('junotoys_sc_tab')) {	
	function junotoys_sc_tab($atts, $content = null) {
		if (junotoys_in_shortcode_blogger()) return '';
		extract(junotoys_html_decode(shortcode_atts(array(
			// Individual params
			"tab_id" => "",		// get it from VC
			"title" => "",		// get it from VC
			"image" => "",
			"name" => "",
			"description" => "",
			"url" => "",
			// Common params
			"id" => "",
			"class" => "",
			"css" => ""
		), $atts)));
		
		if ($image > 0) {
			$attach = wp_get_attachment_image_src($image, 'full');
			if (isset($attach[0]) && $attach[0]!='')
				$image = $attach[0];
		}
		
		junotoys_storage_inc_array('sc_tab_data', 'counter');
		$counter = junotoys_storage_get_array('sc_tab_data', 'counter');
		if (empty($id))
			$id = !empty($tab_id) ? $tab_id : junotoys_storage_get_array('sc_tab_data', 'id').'_'.intval($counter);
		$sc_tab_titles = junotoys_storage_get_array('sc_tab_data', 'titles');
		if (isset($sc_tab_titles[$counter-1])) {
			$sc_tab_titles[$counter-1]['id'] = $id;
			if (!empty($title))
				$sc_tab_titles[$counter-1]['title'] = $title;
		} else {
			$sc_tab_titles[] = array(
				'id' => $id,
				'title' => $title
			);
		}
		$css .= ($image ? 'background: url('.$image.');' : '');
		
		junotoys_storage_set_array('sc_tab_data', 'titles', $sc_tab_titles);
		$output = '<div id="'.esc_attr($id).'"'
					.' class="sc_tabs_content' 
						. ($counter % 2 == 1 ? ' odd' : ' even') 
						. ($counter == 1 ? ' first' : '') 
						. (!empty($class) ? ' '.esc_attr($class) : '') 
						. '"'
						. ($css!='' ? ' style="'.esc_attr($css).'"' : '') 
						. (!empty($url) ? ' data-href="'.esc_url($url).'"' : '')
						. '>' 
					. '<div class="sc_tab_info">'
						. (!empty($name) ? '<h3 class="sc_tab_title">' . trim(junotoys_strmacros($name)) . '</h3>' : '')
						. (!empty($description) ? '<div class="sc_tab_descr">' . trim(junotoys_strmacros($description)) . '</div>' : '')
					. '</div>'				
			. '</div>';
		return apply_filters('junotoys_shortcode_output', $output, 'trx_tab', $atts, $content);
	}
	junotoys_require_shortcode("trx_tab", "junotoys_sc_tab");
}



/* Register shortcode in the internal SC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'junotoys_sc_tabs_reg_shortcodes' ) ) {
	//add_action('junotoys_action_shortcodes_list', 'junotoys_sc_tabs_reg_shortcodes');
	function junotoys_sc_tabs_reg_shortcodes() {
	
		junotoys_sc_map("trx_tabs", array(
			"title" => esc_html__("Tabs", 'junotoys'),
			"desc" => wp_kses_data( __("Insert tabs in your page (post)", 'junotoys') ),
			"decorate" => true,
			"container" => false,
			"params" => array(
				"initial" => array(
					"title" => esc_html__("Initially opened tab", 'junotoys'),
					"desc" => wp_kses_data( __("Number of initially opened tab", 'junotoys') ),
					"divider" => true,
					"value" => 1,
					"min" => 0,
					"type" => "spinner"
				),
				"width" => junotoys_shortcodes_width(),
				"height" => junotoys_shortcodes_height(),
				"top" => junotoys_get_sc_param('top'),
				"bottom" => junotoys_get_sc_param('bottom'),
				"left" => junotoys_get_sc_param('left'),
				"right" => junotoys_get_sc_param('right'),
				"id" => junotoys_get_sc_param('id'),
				"class" => junotoys_get_sc_param('class'),
				"animation" => junotoys_get_sc_param('animation'),
				"css" => junotoys_get_sc_param('css')
			),
			"children" => array(
				"name" => "trx_tab",
				"title" => esc_html__("Tab", 'junotoys'),
				"desc" => wp_kses_data( __("Tab item", 'junotoys') ),
				"container" => true,
				"params" => array(
					"title" => array(
						"title" => esc_html__("Tab name", 'junotoys'),
						"desc" => wp_kses_data( __("Current tab name", 'junotoys') ),
						"value" => "",
						"type" => "text"
					),
					"image" => array(
						"title" => esc_html__("Image URL", 'junotoys'),
						"desc" => wp_kses_data( __("Select the tab image from the library for this section", 'junotoys') ),
						"readonly" => false,
						"value" => "",
						"type" => "media"
					),
					"name" => array(
						"title" => esc_html__("Title", 'junotoys'),
						"desc" => wp_kses_data( __("Title for the block", 'junotoys') ),
						"value" => "",
						"type" => "textarea"
					),
					"description" => array(
						"title" => esc_html__("Description", 'junotoys'),
						"desc" => wp_kses_data( __("Short description for the block", 'junotoys') ),
						"value" => "",
						"type" => "textarea"
					),
					"url" => array(
						"title" => esc_html__("Link", 'junotoys'),
						"desc" => wp_kses_data( __("Link of the block", 'junotoys') ),
						"value" => "",
						"type" => "text"
					),
					"id" => junotoys_get_sc_param('id'),
					"class" => junotoys_get_sc_param('class'),
					"css" => junotoys_get_sc_param('css')
				)
			)
		));
	}
}


/* Register shortcode in the VC Builder
-------------------------------------------------------------------- */
if ( !function_exists( 'junotoys_sc_tabs_reg_shortcodes_vc' ) ) {
	//add_action('junotoys_action_shortcodes_list_vc', 'junotoys_sc_tabs_reg_shortcodes_vc');
	function junotoys_sc_tabs_reg_shortcodes_vc() {
	
		$tab_id_1 = 'sc_tab_'.time() . '_1_' . rand( 0, 100 );
		$tab_id_2 = 'sc_tab_'.time() . '_2_' . rand( 0, 100 );
		vc_map( array(
			"base" => "trx_tabs",
			"name" => esc_html__("Tabs", 'junotoys'),
			"desc" => wp_kses_data( __("Tabs", 'junotoys') ),
			"category" => esc_html__('Content', 'junotoys'),
			'icon' => 'icon_trx_tabs',
			"class" => "trx_sc_collection trx_sc_tabs",
			"content_element" => true,
			"is_container" => true,
			"show_settings_on_create" => false,
			"as_parent" => array('only' => 'trx_tab'),
			"params" => array(
				array(
					"param_name" => "initial",
					"heading" => esc_html__("Initially opened tab", 'junotoys'),
					"desc" => wp_kses_data( __("Number of initially opened tab", 'junotoys') ),
					"class" => "",
					"value" => 1,
					"type" => "textfield"
				),
				junotoys_get_vc_param('id'),
				junotoys_get_vc_param('class'),
				junotoys_get_vc_param('animation'),
				junotoys_get_vc_param('css'),
				junotoys_vc_width(),
				junotoys_vc_height(),
				junotoys_get_vc_param('margin_top'),
				junotoys_get_vc_param('margin_bottom'),
				junotoys_get_vc_param('margin_left'),
				junotoys_get_vc_param('margin_right')
			),
			'default_content' => '
				[trx_tab title="' . esc_html__( 'Tab 1', 'junotoys' ) . '" tab_id="'.esc_attr($tab_id_1).'"][/trx_tab]
				[trx_tab title="' . esc_html__( 'Tab 2', 'junotoys' ) . '" tab_id="'.esc_attr($tab_id_2).'"][/trx_tab]
			',
			"custom_markup" => '
				<div class="wpb_tabs_holder wpb_holder vc_container_for_children">
					<ul class="tabs_controls">
					</ul>
					%content%
				</div>
			',
			'js_view' => 'VcTrxTabsView'
		) );
		
		
		vc_map( array(
			"base" => "trx_tab",
			"name" => esc_html__("Tab item", 'junotoys'),
			"desc" => wp_kses_data( __("Single tab item", 'junotoys') ),
			"show_settings_on_create" => true,
			"class" => "trx_sc_collection trx_sc_tab",
			"content_element" => false,
			"is_container" => false,
			'icon' => 'icon_trx_tab',
			"as_child" => array('only' => 'trx_tabs'),
			"as_parent" => array('except' => 'trx_tabs'),
			"params" => array(
				array(
					"param_name" => "title",
					"heading" => esc_html__("Tab name", 'junotoys'),
					"desc" => wp_kses_data( __("Name for current tab", 'junotoys') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "tab_id",
					"heading" => esc_html__("Tab ID", 'junotoys'),
					"desc" => wp_kses_data( __("ID for current tab (required). Please, start it from letter.", 'junotoys') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textfield"
				),
				array(
					"param_name" => "image",
					"heading" => esc_html__("Image URL", 'junotoys'),
					"description" => wp_kses_data( __("Select the promo image from the library for this section", 'junotoys') ),
					"class" => "",
					"value" => "",
					"type" => "attach_image"
				),
				array(
					"param_name" => "name",
					"heading" => esc_html__("Title", 'junotoys'),
					"description" => wp_kses_data( __("Title for the block", 'junotoys') ),
					"admin_label" => true,
					"class" => "",
					"value" => "",
					"type" => "textarea"
				),
				array(
					"param_name" => "description",
					"heading" => esc_html__("Description", 'junotoys'),
					"description" => wp_kses_data( __("Description for the block", 'junotoys') ),
					"class" => "",
					"value" => "",
					"type" => "textarea"
				),
				array(
					"param_name" => "url",
					"heading" => esc_html__("Link", 'junotoys'),
					"description" => wp_kses_data( __("Link of the block", 'junotoys') ),
					"value" => '',
					"type" => "textfield"
				),				
				junotoys_get_vc_param('id'),
				junotoys_get_vc_param('class'),
				junotoys_get_vc_param('css')
			),
		  'js_view' => 'VcTrxTabView'
		) );
		class WPBakeryShortCode_Trx_Tabs extends JUNOTOYS_VC_ShortCodeTabs {}
		class WPBakeryShortCode_Trx_Tab extends JUNOTOYS_VC_ShortCodeSingle {}
	}
}
?>